/****************************************************************
 * Rather generic header file.
 *
 * Author/copyright:  Duncan Buell
 * Date: 7 May 2015
 *
**/

#ifndef MAIN_H
#define MAIN_H

#include <iostream>
using namespace std;

#include "../../Utilities/utils.h"
#include "../../Utilities/scanner.h"
#include "../../Utilities/scanline.h"

#include "graphcode.h"
#include "node.h"

#endif // MAIN_H
