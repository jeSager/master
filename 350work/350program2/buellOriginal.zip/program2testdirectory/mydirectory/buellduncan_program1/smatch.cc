#include "smatch.h"

/******************************************************************************
 *3456789 123456789 123456789 123456789 123456789 123456789 123456789 123456789
 * Class 'SMatch' for testing gcd algorithms.
 *
 * Author: Duncan A. Buell
 * Date last modified: 20 August 2016
**/

/******************************************************************************
 * Constructor
**/
SMatch::SMatch() {
}

/******************************************************************************
 * Destructor
**/
SMatch::~SMatch() {
}

/******************************************************************************
 * General functions.
**/
/******************************************************************************
 * Function to create DNA strings.
void SMatch::CreateDNA() {
  string thedna = "";
  MyRandom myrandom;

  for (int i = 0; i < 100; ++i) {
    int r = myrandom.RandomUniformInt(0, 100);
    if (r < 50) {
      thedna += "A";
    } else if (r < 75) {
      thedna += "C";
    } else if (r < 90) {
      thedna += "T";
    } else {
      thedna += "G";
    }
  }
  cout << thedna << endl;
}
**/

/******************************************************************************
 * Function to find matches of patterns in the text.
**/
void SMatch::FindMatches() {
}

/******************************************************************************
 * Function to read the patterns.
**/
void SMatch::ReadPatterns(Scanner& in_scanner)
{
  while (in_scanner.HasNext()) {
    string input = in_scanner.NextLine();
    the_patterns_.push_back(input);
  }
}

/******************************************************************************
 * Function to read the text.
**/
void SMatch::ReadText(Scanner& in_scanner)
{
  while (in_scanner.HasNext()) {
    string input = in_scanner.NextLine();
    the_text_.push_back(input);
  }
}

/******************************************************************************
 * Function to 'ToString' the 'vector' of patterns.
**/
string SMatch::ToStringPatterns() {
  string s = "";

  for(vector<string>::iterator it = the_patterns_.begin();
                               it != the_patterns_.end(); ++it) {
    s += (*it) + "\n";
  }

  return s;
}


/******************************************************************************
 * Function to 'ToString' the 'vector' of text.
**/
string SMatch::ToStringText() {
  string s = "";

  for(vector<string>::iterator it = the_text_.begin();
                               it != the_text_.end(); ++it) {
    s += " " + (*it);
  }

  return s;
}

